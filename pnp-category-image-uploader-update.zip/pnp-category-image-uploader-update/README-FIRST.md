# Pressed In Pink: Category Image Uploader Update

This package was built from the current project ZIP you supplied. It changes only:

- `app/admin/catalog/page.tsx`
- `supabase/functions/upload-wrap/index.ts`

It does not replace the wrap galleries, category routes, invoice system, cart, authentication, or database migrations.

## What this adds

The Wrap Catalog Manager now includes a **Category Card Image** section.

You can:

- upload a category image while creating a new category;
- replace the image for an existing category;
- save a category image without uploading wraps;
- select a category image and wrap files together, then publish everything in one workflow;
- preview the selected category image before uploading it.

The browser converts the category image to WebP before upload. The Edge Function stores it in R2 under a versioned path similar to:

`category-cards/marie-the-aristocats-<timestamp>-<id>.webp`

Versioned filenames prevent Cloudflare and browser caching from showing an older category image after replacement. The database's `card_image_url` is updated automatically. No manual SQL is needed.

## 1. Upload the ZIP to Codespaces

Place:

`pnp-category-image-uploader-update.zip`

inside:

`/workspaces/pressedinpink`

## 2. Extract and install

Run these commands one at a time:

```bash
cd /workspaces/pressedinpink
```

```bash
rm -rf pnp-category-image-uploader-update
unzip -o pnp-category-image-uploader-update.zip
```

```bash
bash pnp-category-image-uploader-update/install.sh /workspaces/pressedinpink
```

The installer backs up the current two files inside:

`.pnp-backups/category-image-uploader-<date-and-time>/`

## 3. Verify the files

```bash
grep -n "Category Card Image" app/admin/catalog/page.tsx
```

```bash
grep -n 'action === "category-image"' supabase/functions/upload-wrap/index.ts
```

```bash
grep -n "category-cards" supabase/functions/upload-wrap/index.ts
```

Each command should return at least one matching line.

## 4. Deploy the updated Supabase uploader

This step is required because the Edge Function now accepts category images:

```bash
npx supabase functions deploy upload-wrap
```

Wait for Supabase to confirm a successful deployment.

No new Supabase secret is needed. The working R2 credentials and permanent `images.pressedinpink.com` URL logic remain unchanged.

## 5. Build the website

The admin page changed, so rebuild the site:

```bash
rm -rf .next out
npm run build
```

Do not continue if the build fails.

Confirm the admin catalog page exported:

```bash
ls -lah out/admin/catalog/index.html
```

## 6. Save the update to GitHub

```bash
git add   app/admin/catalog/page.tsx   supabase/functions/upload-wrap/index.ts
```

```bash
git commit -m "Add category image uploads to catalog manager"
```

```bash
git push origin main
```

If Cloudflare deploys automatically from GitHub, wait for that deployment to finish.

For a manual deployment of the successful local build:

```bash
npx wrangler deploy
```

## 7. Use the new category-image tool

Open the PNP admin dashboard and go to **Wrap Catalog Manager**.

### Replace an existing category image

1. Choose the existing category, such as **Marie & the Aristocats**.
2. Under **Category Card Image**, choose the correct image from the computer.
3. Review the preview.
4. Click **Upload / Replace Category Image**.
5. Refresh the public Wraps page.

### Create a new category with its image

1. Click **Create New Category**.
2. Enter the category name, slug, wrap label, filename prefix, description, and keywords.
3. Choose the category card image.
4. Either:
   - click **Create Category & Save Image**, then upload wraps; or
   - choose the wrap images and click **Convert to WebP & Publish**. The category image is saved first automatically.

### Replace only the category image later

Select the category, choose a new image, and click **Upload / Replace Category Image**. The uploader uses a new versioned R2 filename, so the replacement should appear without stale-cache problems.

## 8. Test before the next large batch

Use one category and one test image first:

1. Replace its category card image.
2. Confirm the card updates on `/wraps/`.
3. Upload one wrap.
4. Confirm the thumbnail and full viewer image load.
5. Then continue with the larger batch.

## No SQL migration is required

The existing `catalog_categories.card_image_url` field is reused. The Edge Function updates it directly after the R2 upload succeeds.

## Rollback

Find the newest backup:

```bash
ls -dt .pnp-backups/category-image-uploader-* | head -1
```

Then copy the two backed-up files into their original locations and redeploy/rebuild.
