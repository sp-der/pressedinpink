# Included behavior

## Admin Catalog page

- Shows the current category card image.
- Lets the admin choose and preview a replacement.
- Converts category artwork to WebP in the browser.
- Supports image-only category creation/update.
- Supports category image plus wrap upload in one workflow.

## Supabase upload-wrap function

- Adds the `category-image` action.
- Uploads category artwork to the existing R2 bucket.
- Uses a unique versioned filename to prevent stale cache.
- Updates `catalog_categories.card_image_url`.
- Removes an older R2 category-card object when it is safe to do so.
- Preserves the permanent public image origin used by the working wrap uploader.
- Keeps the existing first-wrap fallback only when no dedicated category image exists.
