#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${1:-/workspaces/pressedinpink}"
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_DIR="$PROJECT_DIR/.pnp-backups/category-image-uploader-$(date +%Y%m%d-%H%M%S)"

PAGE_SOURCE="$PACKAGE_DIR/files/app/admin/catalog/page.tsx"
FUNCTION_SOURCE="$PACKAGE_DIR/files/supabase/functions/upload-wrap/index.ts"

PAGE_TARGET="$PROJECT_DIR/app/admin/catalog/page.tsx"
FUNCTION_TARGET="$PROJECT_DIR/supabase/functions/upload-wrap/index.ts"

for required in "$PAGE_SOURCE" "$FUNCTION_SOURCE"; do
  if [[ ! -f "$required" ]]; then
    echo "Missing package file: $required"
    exit 1
  fi
done

if [[ ! -d "$PROJECT_DIR" ]]; then
  echo "Project folder not found: $PROJECT_DIR"
  exit 1
fi

mkdir -p "$BACKUP_DIR/app/admin/catalog"
mkdir -p "$BACKUP_DIR/supabase/functions/upload-wrap"

if [[ -f "$PAGE_TARGET" ]]; then
  cp "$PAGE_TARGET" "$BACKUP_DIR/app/admin/catalog/page.tsx"
fi

if [[ -f "$FUNCTION_TARGET" ]]; then
  cp "$FUNCTION_TARGET" "$BACKUP_DIR/supabase/functions/upload-wrap/index.ts"
fi

mkdir -p "$(dirname "$PAGE_TARGET")"
mkdir -p "$(dirname "$FUNCTION_TARGET")"

cp "$PAGE_SOURCE" "$PAGE_TARGET"
cp "$FUNCTION_SOURCE" "$FUNCTION_TARGET"

echo
echo "Installed the category-image uploader update."
echo "Backup folder:"
echo "  $BACKUP_DIR"
echo
echo "Next commands:"
echo "  npx supabase functions deploy upload-wrap"
echo "  rm -rf .next out"
echo "  npm run build"
echo
echo "Then commit these two files:"
echo "  app/admin/catalog/page.tsx"
echo "  supabase/functions/upload-wrap/index.ts"
