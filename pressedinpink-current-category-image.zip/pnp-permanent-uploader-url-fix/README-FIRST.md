# Pressed In Pink permanent uploader URL fix

This package fixes the repeating blank-image problem at both layers:

1. The Supabase `upload-wrap` Edge Function now always uses the production
   image origin `https://images.pressedinpink.com`.
2. The database automatically rebuilds uploaded image URLs from the raw R2
   object keys before saving them.

The package changes only:

- `supabase/functions/upload-wrap/index.ts`
- one new SQL migration file

It does not touch galleries, routes, invoice code, cart code, or category pages.

## Install in Codespaces

```bash
cd /workspaces/pressedinpink
rm -rf pnp-permanent-uploader-url-fix
unzip -o pnp-permanent-uploader-url-fix.zip
bash pnp-permanent-uploader-url-fix/install.sh /workspaces/pressedinpink
```

Verify:

```bash
grep -n "PUBLIC_IMAGE_ORIGIN\|buildPublicObjectUrl"   supabase/functions/upload-wrap/index.ts
```

## Deploy the corrected uploader

```bash
npx supabase functions deploy upload-wrap
```

The `R2_PUBLIC_BASE_URL` secret is no longer used by this version. You may
leave it in Supabase, but it cannot change uploaded image URLs anymore.

## Install the database safety net

Open:

`supabase/pnp-permanent-uploader-url-fix.sql`

Copy the entire file into Supabase Dashboard > SQL Editor > New query and run it
once.

The SQL repairs existing R2-backed records and creates triggers that protect
future uploads.

## Test

Upload one test wrap into Alice in Wonderland.

It should appear immediately in:
- the thumbnail grid
- the full-size viewer
- the category card, when the category has no custom card image

No follow-up repair SQL should be needed.

## Save to GitHub

```bash
git add   supabase/functions/upload-wrap/index.ts   supabase/pnp-permanent-uploader-url-fix.sql

git commit -m "Permanently normalize uploaded wrap image URLs"
git push origin main
```

No Next.js build or Wrangler deployment is required for this uploader fix.
