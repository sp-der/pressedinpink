#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${1:-/workspaces/pressedinpink}"
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_FILE="$PACKAGE_DIR/files/supabase/functions/upload-wrap/index.ts"
TARGET_FILE="$PROJECT_DIR/supabase/functions/upload-wrap/index.ts"
BACKUP_DIR="$PROJECT_DIR/.pnp-backups/permanent-uploader-url-fix-$(date +%Y%m%d-%H%M%S)"

if [[ ! -d "$PROJECT_DIR" ]]; then
  echo "Project folder not found: $PROJECT_DIR"
  exit 1
fi

if [[ ! -f "$SOURCE_FILE" ]]; then
  echo "Package uploader file not found: $SOURCE_FILE"
  exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$TARGET_FILE")"

if [[ -f "$TARGET_FILE" ]]; then
  cp "$TARGET_FILE" "$BACKUP_DIR/index.ts"
fi

cp "$SOURCE_FILE" "$TARGET_FILE"
cp \
  "$PACKAGE_DIR/files/supabase/pnp-permanent-uploader-url-fix.sql" \
  "$PROJECT_DIR/supabase/pnp-permanent-uploader-url-fix.sql"

echo "Installed permanent uploader URL fix."
echo "Backup: $BACKUP_DIR"
echo
echo "Verify with:"
echo 'grep -n "PUBLIC_IMAGE_ORIGIN\|buildPublicObjectUrl" supabase/functions/upload-wrap/index.ts'
