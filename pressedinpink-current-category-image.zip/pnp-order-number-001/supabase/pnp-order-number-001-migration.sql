-- PRESSED IN PINK
-- SEQUENTIAL ORDER NUMBERS: #001, #002, #003...
--
-- What this migration does:
-- 1. Renumbers existing orders oldest-first beginning at #001.
-- 2. Resets public.order_number_seq so the next new order continues correctly.
-- 3. Updates every active public.submit_order overload that still creates
--    PNP-YYYY-000001-style numbers.
--
-- Run this file once in:
-- Supabase Dashboard > SQL Editor > New query
--
-- The entire migration runs inside a transaction. If any required step fails,
-- PostgreSQL rolls everything back.

begin;

-- Prevent a new order from being inserted halfway through the renumbering.
lock table public.orders in exclusive mode;

create sequence if not exists public.order_number_seq
  start with 1
  increment by 1
  minvalue 1;

-- Freeze the new number assigned to every existing order.
-- The oldest order becomes #001.
create temporary table pnp_order_number_map
on commit drop
as
select
  orders.id,
  row_number() over (
    order by
      orders.submitted_at asc,
      orders.id asc
  )::bigint as new_number
from public.orders as orders;

-- Move existing values out of the way first so the unique constraint cannot
-- collide while rows are being renumbered.
update public.orders
set order_number =
  '__PNP_RENUMBERING__'
  || replace(id::text, '-', '');

-- Apply #001, #002, ... and continue naturally beyond #999.
update public.orders as orders
set order_number =
  '#'
  || case
    when mapping.new_number < 1000
      then lpad(
        mapping.new_number::text,
        3,
        '0'
      )
    else mapping.new_number::text
  end
from pnp_order_number_map as mapping
where orders.id = mapping.id;

-- If there are 12 existing orders, the next order will use 13.
-- If there are no orders, the next order will use 1.
select setval(
  'public.order_number_seq',
  greatest(
    coalesce(max(new_number), 0),
    1
  ),
  coalesce(max(new_number), 0) > 0
)
from pnp_order_number_map;

-- Patch the current submit_order function without replacing its contact,
-- portal-token, cart validation, or security logic.
do $migration$
declare
  function_oid oid;
  original_definition text;
  updated_definition text;
  patched_count integer := 0;

  portal_format text := $old_portal$
  v_order_number =
    'PNP-'
    || to_char(
      now(),
      'YYYY'
    )
    || '-'
    || lpad(
      nextval(
        'public.order_number_seq'
      )::text,
      6,
      '0'
    );
$old_portal$;

  original_format text := $old_original$
  v_order_number =
    'PNP-'
    || to_char(now(), 'YYYY')
    || '-'
    || lpad(
      nextval(
        'public.order_number_seq'
      )::text,
      6,
      '0'
    );
$old_original$;

  new_format text := $new_format$
  v_order_number =
    '#'
    || (
      select
        case
          when generated_number.value < 1000
            then lpad(
              generated_number.value::text,
              3,
              '0'
            )
          else generated_number.value::text
        end
      from (
        select nextval(
          'public.order_number_seq'
        ) as value
      ) as generated_number
    );
$new_format$;
begin
  for function_oid in
    select procedures.oid
    from pg_proc as procedures
    join pg_namespace as namespaces
      on namespaces.oid =
        procedures.pronamespace
    where namespaces.nspname = 'public'
      and procedures.proname =
        'submit_order'
  loop
    original_definition =
      pg_get_functiondef(function_oid);

    updated_definition =
      replace(
        original_definition,
        portal_format,
        new_format
      );

    updated_definition =
      replace(
        updated_definition,
        original_format,
        new_format
      );

    if updated_definition
      is distinct from original_definition
    then
      execute updated_definition;
      patched_count = patched_count + 1;
    end if;
  end loop;

  if patched_count = 0 then
    raise exception
      'No submit_order function using the old PNP order-number format was found. No changes were committed.';
  end if;
end;
$migration$;

notify pgrst, 'reload schema';

commit;

-- Verification results shown after a successful run.
select
  order_number,
  customer_name,
  submitted_at
from public.orders
order by
  submitted_at asc,
  id asc;

select
  last_value,
  is_called
from public.order_number_seq;
