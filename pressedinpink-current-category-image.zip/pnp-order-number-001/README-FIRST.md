# Pressed In Pink order numbers starting at #001

This update changes the existing `orders.order_number` values and the database
function that creates future orders.

## Result

- Oldest existing order: `#001`
- Next existing order: `#002`
- Future orders continue sequentially
- Numbers beyond 999 continue as `#1000`, `#1001`, and so on
- Supabase UUID order IDs remain unchanged behind the scenes

## Installation

1. Upload or copy `supabase/pnp-order-number-001-migration.sql` into the
   `/workspaces/pressedinpink` project.
2. Open Supabase Dashboard.
3. Select the Pressed In Pink project.
4. Open **SQL Editor**.
5. Click **New query**.
6. Open the SQL file in Codespaces, copy the entire contents, and paste them
   into the Supabase query.
7. Click **Run** once.
8. Confirm that the result table shows `#001`, `#002`, and so on.
9. Place one test order. It should receive the next sequential number.
10. Commit the migration file to GitHub.

## Git commands

```bash
cd /workspaces/pressedinpink
git add supabase/pnp-order-number-001-migration.sql
git commit -m "Start customer order numbers at 001"
git push origin main
```

## No additional deployment is required

Do not run `npm run build`, Wrangler, or deploy any Supabase Edge Function for
this change. The order number is generated inside the Supabase database, and
the website, emails, admin dashboard, customer pages, and PDF invoices already
read the saved `order_number` value.

## Important

Do not rerun older order schema migration files after this migration. They
contain the historical `PNP-YYYY-000001` format. This new migration should
remain the latest order-number migration.
