#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="${1:-$(pwd)}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$PROJECT_ROOT/.pnp-backups/invoice-fix-$STAMP"

required=(
  "$PROJECT_ROOT/app/admin/order/page.tsx"
  "$PROJECT_ROOT/lib/invoicePdf.ts"
  "$SCRIPT_DIR/files/app/admin/order/page.tsx"
  "$SCRIPT_DIR/files/lib/invoicePdf.ts"
)

for file in "${required[@]}"; do
  if [[ ! -f "$file" ]]; then
    echo "Missing required file: $file" >&2
    exit 1
  fi
done

mkdir -p "$BACKUP_DIR/app/admin/order" "$BACKUP_DIR/lib"
cp "$PROJECT_ROOT/app/admin/order/page.tsx" "$BACKUP_DIR/app/admin/order/page.tsx"
cp "$PROJECT_ROOT/lib/invoicePdf.ts" "$BACKUP_DIR/lib/invoicePdf.ts"

cp "$SCRIPT_DIR/files/app/admin/order/page.tsx" "$PROJECT_ROOT/app/admin/order/page.tsx"
cp "$SCRIPT_DIR/files/lib/invoicePdf.ts" "$PROJECT_ROOT/lib/invoicePdf.ts"

echo "Invoice fix installed."
echo "Backup saved to: $BACKUP_DIR"
echo "Next run: rm -rf .next out && npm run build"
