# Pressed In Pink invoice-only fix

This package changes only these two project files:

- `app/admin/order/page.tsx`
- `lib/invoicePdf.ts`

It does not replace wrap routes, gallery files, the Princesses uploader, authentication, or catalog files.

## What this fixes

- Groups invoice rows by wrap category instead of individual design.
- Counts approved, available wraps across the whole order.
- Applies `$2.00` to every wrap when the approved total is 1–49.
- Applies `$1.25` to every wrap when the approved total is 50 or more.
- Keeps shipping, tax, discount, and invoice notes editable.
- Saves grouped category rows to `invoice_items`.
- Updates the downloaded and emailed PDF with the grouped rows and redesigned top banner.
- Leaves individual wrap designs visible in the admin order review below the invoice.

## Install in GitHub Codespaces

Upload `pnp-invoice-only-fix.zip` into the main `/workspaces/pressedinpink` folder.

From the project root, run each command separately:

```bash
cd /workspaces/pressedinpink
rm -rf pnp-invoice-only-fix
unzip -o pnp-invoice-only-fix.zip
bash pnp-invoice-only-fix/install.sh /workspaces/pressedinpink
```

The installer makes a timestamped backup inside:

```text
.pnp-backups/
```

## Build before pushing

```bash
rm -rf .next out
npm run build
```

Do not push if the build fails. Send the full build error instead.

## Confirm the exported admin page

```bash
ls -lah out/admin/order/index.html
```

## Save to GitHub

```bash
git add app/admin/order/page.tsx lib/invoicePdf.ts
git commit -m "Group invoices by category and automate wrap pricing"
git push origin main
```

Cloudflare should start a new build after the push.

## No SQL is required

The existing `invoice_items.order_item_id` column already permits `NULL`, so grouped category rows can be stored without linking each invoice row to one individual wrap design.

## Test checklist

1. Open an order with fewer than 50 approved wraps. The active price must show `$2.00 each`.
2. Change approved quantities so the entire order reaches 50. Every category row must change to `$1.25 each`.
3. Confirm multiple designs in the same category appear as one invoice row.
4. Confirm shipping, tax, and discount change the final total correctly.
5. Save, download, and email a test invoice.
6. Confirm individual designs remain visible in the order review section.

## Existing draft invoices

Opening an older draft will keep its saved shipping, tax, discount, and notes. The grouped wrap subtotal and automatic rate are recalculated from the order's current approved quantities when the invoice is saved again.
