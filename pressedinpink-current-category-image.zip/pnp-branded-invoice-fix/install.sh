#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${1:-/workspaces/pressedinpink}"
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_FILE="$PACKAGE_DIR/files/lib/invoicePdf.ts"
TARGET_FILE="$PROJECT_DIR/lib/invoicePdf.ts"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$PROJECT_DIR/.pnp-backups/invoice-branding-$TIMESTAMP"

if [ ! -d "$PROJECT_DIR" ]; then
  echo "Project directory not found: $PROJECT_DIR"
  exit 1
fi

if [ ! -f "$SOURCE_FILE" ]; then
  echo "Package file not found: $SOURCE_FILE"
  exit 1
fi

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$TARGET_FILE")"

if [ -f "$TARGET_FILE" ]; then
  cp "$TARGET_FILE" "$BACKUP_DIR/invoicePdf.ts"
fi

cp "$SOURCE_FILE" "$TARGET_FILE"

echo "Installed branded invoice PDF generator."
echo "Updated: $TARGET_FILE"
echo "Backup:  $BACKUP_DIR"
echo
echo "Next:"
echo "  cd $PROJECT_DIR"
echo "  rm -rf .next out"
echo "  npm run build"
