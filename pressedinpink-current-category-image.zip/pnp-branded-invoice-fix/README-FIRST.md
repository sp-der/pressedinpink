# Pressed In Pink Branded PDF Invoice Fix

This package changes only:

- `lib/invoicePdf.ts`

It does not touch wrap category routes, the Princesses uploader, customer galleries,
authentication, Supabase tables, or the admin invoice-builder page.

## What the new PDF includes

- Pressed In Pink lips logo
- Pressed In Pink script logo
- Black, charcoal, red, and white website styling
- Improved built-in PDF typography
- Category-grouped invoice rows
- Automatic rate and total display
- Styled customer and order details
- Styled shipping, tax, discount, and total box
- Notes area
- Branded footer
- Multi-page support

The two logos are embedded inside the PDF generator. No extra image-loading request is
needed when downloading or emailing an invoice.

## Install in GitHub Codespaces

Place `pnp-branded-invoice-fix.zip` in:

`/workspaces/pressedinpink`

Run these commands one at a time:

```bash
cd /workspaces/pressedinpink
```

```bash
rm -rf pnp-branded-invoice-fix
unzip -o pnp-branded-invoice-fix.zip
```

```bash
bash pnp-branded-invoice-fix/install.sh /workspaces/pressedinpink
```

The installer creates a backup under:

`.pnp-backups/invoice-branding-YYYYMMDD-HHMMSS/`

## Build before pushing

```bash
rm -rf .next out
npm run build
```

Do not push if the build fails.

## Save to GitHub

```bash
git add lib/invoicePdf.ts
git commit -m "Redesign PDF invoice with Pressed In Pink branding"
git push origin main
```

Cloudflare should rebuild automatically after the push.

## Test

Open an order in the PNP admin dashboard and:

1. Generate or save the invoice.
2. Download the invoice PDF.
3. Confirm both logos appear in the top banner.
4. Confirm invoice rows are grouped by category.
5. Confirm shipping, tax, discount, and final total are correct.
6. Email a test invoice and confirm the attachment uses the same branded design.

## Preview

A sample PDF is included at:

`preview/pnp-branded-invoice-preview.pdf`

## No extra deployment steps

You do not need to:

- Run Supabase SQL
- Redeploy a Supabase function
- Run Wrangler manually, unless your Cloudflare project is not connected to GitHub
